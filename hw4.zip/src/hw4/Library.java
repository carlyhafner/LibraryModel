package hw4;

import java.util.ArrayList;

/**
 * A Library consists of a list of items and a list of patrons
 * who can check out items.
 */
public class Library
{
  /**
   * The items in this library.
   */
  private ArrayList<LibraryItem> items;
  
  /**
   * The list of patrons of this library.
   */
  private ArrayList<LibraryPatron> patrons;
  
  /**
   * Constructs a Library with no books and no patrons.
   */
  public Library()
  {
    items = new ArrayList<LibraryItem>();
    patrons = new ArrayList<LibraryPatron>();
  }
  
  /**
   * Adds an item to this library's list of items.
   * @param item the item to be added
   */
  public void addItem(LibraryItem item)
  {
    items.add(item);
  }
  
  /**
   * Adds a patron to this library's list of patrons.
   * @param patron the patron to be added
   */
  public void addPatron(LibraryPatron patron)
  {
    patrons.add(patron);
  }
  
  /**
   * Returns the patron with the given name
   * @param name the name of the patron to search for
   * @return the patron 
   */
  public LibraryPatron findUser(String name)
  {
    for (LibraryPatron p : patrons)
    {
      if (name.equals(p.getName()))
      {
        return p;
      }
    }
    return null;
  }
  
  /**
   * Search the library's collection of for items satisfying the
   * given SearchCondition.
   * @param condition the SearchCondition
   * @return list of items satisfying the condition
   */
  public ArrayList<LibraryItem> search(SearchCondition condition)
  {
    ArrayList<LibraryItem> results = new ArrayList<LibraryItem>();
    for (LibraryItem item : items)
    {
      if (condition.matches(item))
      {
        results.add(item);
      }
    }
    return results;   
  }
  
}
